#Detect fake profiles in online social networks#

Freelancer.com project URL: https://www.freelancer.in/projects/Python/Write-some-Software-9045568/

##install all python dependencies as mentioned below##

* pip
* numpy
* pandas
* ipython
* ipython notebook
* matplotlib
* sexmachine
* scikit-learn
* pybrain

## if you want to re-run code then it can be done in two ways-##
  1- using ipython notebook(recommneded)
  
     `$ ipython notebook`
	
      now all .ipynb files will be shown in browser, open any file and run 
  2- using python on terminal
  
     `$ python <file>.py`

### all output has been saved in html and pdf form in html and pdf folders###

<a href="https://www.buymeacoffee.com/cognitivecamp" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" style="height: 51px !important;width: 217px !important;" ></a>
